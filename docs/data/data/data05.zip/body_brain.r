#' 線形回帰分析(単回帰)の例
#' - Brain and Body Weights for 28 Species

#' パッケージの読み込み
library(conflicted) # 名前の衝突に対応するパッケージ
library(tidyverse)
conflicts_prefer( # 衝突する可能性のあるものは tidyverse の関数を優先
    dplyr::filter(),
    dplyr::select(),
    dplyr::lag(),
    )
library(ggfortify)

#' データの整理 ("MASS::Animals"を用いる)
animals <-
    rownames_to_column(MASS::Animals, var = "species") |>
    as_tibble()

#' データの内容を確認
?MASS::Animals  # 内容の詳細を表示 
View(animals)

#' データのプロット (normal plot)
p <- animals |> 
    ggplot(aes(x = body, y = brain)) +
    geom_point(colour = "royalblue") + 
    ggrepel::geom_text_repel(aes(label = species), size = 3)  # ラベル表示(自動調整)

p + #' ラベルの重なりが多いため警告が出る
    labs(title = "Brain and Body Weights (normal plot)",
         x = "body [kg]", y = "brain [g]") 

p + scale_x_log10() + scale_y_log10() + # 対数変換
    labs(title = "Brain and Body Weights (log-log plot)",
         x = "body [kg]", y = "brain [g]")

#' 回帰分析 (単回帰)
estimate <- lm(log(brain) ~ log(body), # 種をデータ名として分析
               data = column_to_rownames(animals, "species"))
summary(estimate) # 分析結果のまとめを表示

#' 回帰式および信頼区間の表示
p + scale_x_log10() + scale_y_log10() + # 対数変換
    geom_smooth(method = lm, formula = y ~ x,
                level = 0.95) + # lm による回帰式と95%信頼区間
    labs(title="Brain and Body Weights", x="body [kg]", y="brain [g]")

#' 回帰式および信頼区間・予測区間の表示
conf_int <- exp(predict(estimate,
                        newdata = animals,
                        interval = "confidence"))
colnames(conf_int) <- paste0("c.", colnames(conf_int))
pred_int <- exp(predict(estimate,
                        newdata = animals,
                        interval = "prediction"))
colnames(pred_int) <- paste0("p.", colnames(pred_int))

bind_cols(animals, conf_int, pred_int) |>
    ggplot(aes(x = body, y = brain, label = species)) +
    scale_x_log10() + scale_y_log10() + # log-log plot
    geom_line(aes(y = c.fit), colour = "dodgerblue", linewidth = 1.2) +
    geom_ribbon(aes(ymin = c.lwr, ymax = c.upr),
                fill = "blue", alpha = 0.2)+
    geom_ribbon(aes(ymin = p.lwr, ymax = p.upr),
                fill = "blue", alpha = 0.1)+
    geom_point(colour = "royalblue") + 
    ggrepel::geom_text_repel(size = 3) +
    labs(title = "Brain and Body Weights",
         x = "body [kg]", y = "brain [g]")

#' 診断プロット
autoplot(estimate,
         colour = "royalblue", # データ点の修飾
         label.size = 3, label.n = 4, label.colour = "darkred", # ラベルの修飾
         label.repel = TRUE, # ggrepel を利用
         smooth.colour = "gray50", smooth.linetype = "dashed", # 補助線の修飾
         ad.colour = "darkgreen") # その他の補助線の修飾

#' 外れ値を除いた回帰分析
#' 以下上書きして同じコードを再利用
estimate <- lm(log(brain) ~ log(body),
               data = column_to_rownames(animals, "species"),
               subset = -c(6,16,26)) # 外れ値の除去(恐竜)
summary(estimate)

#' 回帰式および信頼区間・予測区間の表示
conf_int <- exp(predict(estimate, # 信頼区間
                        newdata = animals,
                        interval = "confidence"))
colnames(conf_int)[2:3] <- # 列名の書き換え
    paste0("c.", colnames(conf_int)[2:3])
pred_int <- exp(predict(estimate, # 予測区間
                        newdata = animals,
                        interval = "prediction"))
colnames(pred_int)[2:3] <- # 列名の書き換え
    paste0("p.", colnames(pred_int)[2:3])

bind_cols(animals, conf_int, pred_int[,-1]) |>
    ggplot(aes(x = body, y = brain, label = species)) +
    scale_x_log10() + scale_y_log10() + # log-log plot
    geom_line(aes(y = fit),
              colour = "dodgerblue", linewidth = 1.2) +
    geom_ribbon(aes(ymin = c.lwr, ymax = c.upr),
                fill = "blue", alpha = 0.2)+
    geom_ribbon(aes(ymin = p.lwr, ymax = p.upr),
                fill = "blue", alpha = 0.1)+
    geom_point(colour = "royalblue") + 
    ggrepel::geom_text_repel(size = 3) +
    labs(title = "Brain and Body Weights",
         x = "body [kg]", y = "brain [g]")

#' 診断プロット
autoplot(estimate,
         colour = "royalblue", # データ点の修飾
         label.size = 3, label.n = 4, label.colour = "darkred", # ラベルの修飾
         label.repel = TRUE, # ggrepel を利用
         smooth.colour = "gray50", smooth.linetype = "dashed", # 補助線の修飾
         ad.colour = "darkgreen") # その他の補助線の修飾
