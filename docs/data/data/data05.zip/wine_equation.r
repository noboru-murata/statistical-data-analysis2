#' 線形回帰分析の例
#' - Ashenfelter's Wine Equation
#' 
#' Bordeaux Wine Vintage Quality and the Weather
#' http://www.liquidasset.com/orley.htm
#' 
#'   Data and Results for Wine Regressions 
#'     as Reported in Chance Magazine
#'                 by Ashenfelter, Ashmore and Lalonde
#' http://www.liquidasset.com/winedata.html
#'
#' wine.csv (上記のwebからデータを取得し整理)
#' VINT : Vintage (Year)
#' LPRICE2 : Logarithm of Average Vintage Price Relative to 1961
#' WRAIN   : Winter (Oct.-March) Rain 
#' DEGREES : Average Temperature (April-Sept.)
#' HRAIN   : Harvest (August and Sept.) Rain 
#' TIME_SV : Time since Vintage (Years) 
#'
#' cf. The Ashenfelter Wine Quality Index [1950-2020]
#' https://www.worldwineweather.com/ashenfelter-wine-quality-index-1950-2020/
            
#' パッケージの読み込み
library(conflicted) # 名前の衝突に対応するパッケージ
library(tidyverse)
conflicts_prefer( # 衝突する可能性のあるものは tidyverse の関数を優先
    dplyr::filter(),
    dplyr::select(),
    dplyr::lag(),
    )
library(ggfortify)

#' データの読み込み
wine <- read_csv(file="wine.csv")

#' データの内容を確認
View(wine)

#' データの散布図
#' 標準的な図
wine |> na.exclude() |> # 欠損(NA)データを除去
    GGally::ggpairs(
                columns = 2:6,
                lower = list(continuous = GGally::wrap("smooth_loess", colour = "blue"))) +
    theme(axis.title.x = element_text(size = 8), # 文字の大きさを調整
          axis.title.y = element_text(size = 8)) 
#' 価格帯を分類して色分け
wine |> na.exclude() |>
    mutate(class = cut(LPRICE2, breaks = 3)) |> # 3分割
    GGally::ggpairs(mapping = aes(colour = class),
                    columns = 2:6) + 
    theme(axis.title.x = element_text(size = 8), 
          axis.title.y = element_text(size = 8)) 

#' 対数変換されたボルドーワインの価格(LPRICE2)を
#' 冬期降雨量(WRAIN)，育成期平均気温(DEGREES)，収穫期降雨量(HRAIN)，年数(TIME_SV)
#' で回帰する
estimate <- lm(LPRICE2 ~ ., # VINTをデータ点の名前として利用
               data = column_to_rownames(wine, "VINT"))
summary(estimate)
round(coef(estimate), digits = 4) # 係数を確認する(小数点以下4桁)

#' 診断プロット
autoplot(estimate) # 既定値の簡便な表示を
#' autoplot(estimate, which = 1) # res vs fit
#' autoplot(estimate, which = 2) # qq plot
#' autoplot(estimate, which = 4) # Cook's dist
#' autoplot(estimate, which = 1:6) # 全てを表示
autoplot(estimate, # 表示の変更例
         colour = "royalblue", # データ点の修飾
         label.size = 3, label.n = 4, label.colour = "darkred", # ラベルの修飾
         label.repel = TRUE, # ggrepel を利用
         smooth.colour = "gray50", smooth.linetype = "dashed", # 補助線の修飾
         ad.colour = "darkgreen") # その他の補助線の修飾

#' 回帰による予測結果を比較
wine_summary <- bind_cols(
    mutate(wine,
           year = as.integer(VINT),
           price = exp(wine[["LPRICE2"]])),
    exp(predict(estimate,
                newdata = wine,
                interval = "prediction")))

#' 実測値と予測値の比較
wine_summary |>
    ggplot(aes(x = price, y = fit, label = year)) +
    scale_x_log10() + scale_y_log10() + # log-log plot
    geom_point(colour = "royalblue", na.rm = TRUE) + 
    ggrepel::geom_label_repel(na.rm = TRUE) + # text で表示
    labs(title = "Bordeaux Wine Price (log)",
         x = "Price", y = "Prediction")

#' 各年の比較
colour_label <- fct(c("True Value","Predict"))
wine_summary |>
    ggplot(aes(year, price)) +
    geom_path(aes(y = price, colour = colour_label[1]),
              linewidth = 1, na.rm = TRUE) + # 欠損の処理
    geom_path(aes(y = fit, colour = colour_label[2]),
              linewidth = 1, na.rm = TRUE) + # 欠損の処理
    geom_ribbon(aes(ymin = lwr, ymax = upr, fill = colour_label[2]), 
                alpha = .2, na.rm = TRUE, show.legend = FALSE) +
    scale_fill_discrete(drop = F) + # 色とラベルの対応を固定
    scale_colour_discrete(drop = F) + # 色とラベルの対応を固定
    theme(legend.position = c(.9,.9), # 凡例と文字の向きを調整
          legend.title = element_blank(), 
          axis.text.x = element_text(angle = 90, hjust = 1, vjust = .5)) + 
    labs(title = "Bordeaux Wine Price", x = "Year", y = "Price Ratio")

## 専門家の評価が高かったのは1986年だが，予測では凡庸
## その後1989/1990年の気温(かなり高い)を用いて予測した内容が話題となる
## この予測した結果が正しかったのかどうかは調べてみて下さい
